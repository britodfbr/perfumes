email_cobranca = 'suporte@lojamodelo.com.br';

produtos={
  '11': ['Bermuda amarela de nylon', '15,00'],
  '12': ['Calça jeans', '98,50'],
  '13': ['Carteira de couro', '50,22']
};
