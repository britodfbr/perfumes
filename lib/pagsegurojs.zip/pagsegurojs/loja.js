loja = {
  'Bebê': [
    {
      'id'    : '00001',
      'descr' : 'Chupeta doce',
      'valor' : 3.4
    },
    {
      'id' : '00002',
      'descr' : 'Papinha de morango',
      'valor' : 7
    },
    {
      'id' : '00003',
      'descr' : 'Papinha de maracujá',
      'valor' : 7
    },
    {
      'id' : '00004',
      'descr' : 'Papinha de cereja',
      'valor' : 7
    },
    {
      'id' : '00005',
      'descr' : 'Papinha de carne moída',
      'valor' : 7.5
    },
    {
      'id' : '00015',
      'descr' : 'Babador elétrico',
      'valor' : 17.56
    }
  ],
  'Eletro-portáteis' : [
    {
      'id' : '00006',
      'descr' : 'MP3 Cougar',
      'valor' : 75.6
    },
    {
      'id' : '00007',
      'descr' : 'Telefone sem fio Dynacon',
      'valor' : 55.3
    }
  ]
}